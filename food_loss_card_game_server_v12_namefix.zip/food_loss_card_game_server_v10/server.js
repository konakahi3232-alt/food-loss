const path=require('path');
const fs=require('fs');
const http=require('http');
const express=require('express');
const {WebSocketServer}=require('ws');

const app=express();
const root=__dirname;
app.use(express.static(path.join(root,'public')));
app.get('/',(req,res)=>{
 const p=fs.existsSync(path.join(root,'public','index.html'))?path.join(root,'public','index.html'):path.join(root,'index.html');
 res.sendFile(p);
});
const server=http.createServer(app);
const wss=new WebSocketServer({server,path:'/ws'});
const rooms=new Map();

const ING={
 egg:['🥚','卵',1], sugar:['🍬','砂糖',1], soy:['🥢','しょうゆ',1], rice:['🍚','米',2], tomato:['🍅','トマト',1], oil:['🫗','油',1], beef:['🥩','牛肉',3], onion:['🧅','たまねぎ',1], pork:['🥓','豚肉',2], chicken:['🍗','鶏肉',2], lettuce:['🥬','レタス',1], bread:['🍞','パン',2], cheese:['🧀','チーズ',2], potato:['🥔','じゃがいも',1], carrot:['🥕','にんじん',1], fish:['🐟','魚',2], butter:['🧈','バター',1]
};
const REC=[
 ['eggroll','卵焼き',['egg','sugar','soy'],5],['omurice','オムライス',['egg','rice','tomato'],6],['friedrice','チャーハン',['rice','egg','oil'],6],['gyudon','牛丼',['beef','rice','onion'],8],['butadon','豚丼',['pork','rice','onion'],7],['oyakodon','親子丼',['egg','chicken','onion'],6],['nikujaga','肉じゃが',['beef','potato','carrot'],7],['curry','カレー',['beef','potato','carrot'],7],['porksaute','ポークソテー',['pork','oil','soy'],6],['stirfry','野菜炒め',['carrot','onion','oil'],5],['tomatosalad','トマトサラダ',['tomato','lettuce','oil'],5],['cheesesand','チーズサンド',['bread','cheese','lettuce'],7],['hamburger','ハンバーガー',['bread','beef','lettuce'],8],['pizzatoast','ピザトースト',['bread','cheese','tomato'],7],['potatosalad','ポテトサラダ',['potato','egg','carrot'],5],['steak','ステーキ',['beef','oil','soy'],7],['sunnyegg','目玉焼き',['egg','oil'],4],['saltmusubi','塩むすび',['rice'],4],['fries','フライドポテト',['potato','oil'],4],['toast','トースト',['bread','butter'],4],['boiledegg','ゆで卵',['egg'],3],['tamago','たまごかけご飯',['egg','rice'],5],['cheesepotato','チーズポテト',['potato','cheese'],5],['sashimi','刺身',['fish'],4],['sandwich','サンドイッチ',['bread','lettuce'],5]
].map(([id,name,need,pts])=>({id,name,need,pts}));
const REC_MAP=Object.fromEntries(REC.map(r=>[r.id,r]));
const DECK=[];
Object.keys(ING).forEach(k=>{for(let i=0;i<4;i++)DECK.push(k)});
function shuffle(a){for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
function canMake(hand,need){const c={};hand.forEach(x=>c[x]=(c[x]||0)+1);return need.every(x=>(c[x]||0)>0)}
function removeNeed(hand,need){const h=[...hand];for(const x of need){const i=h.indexOf(x);if(i<0)return null;h.splice(i,1)}return h}
function point(card){return ING[card]?.[2]??0}
function roomState(room){return {players:room.players.map(p=>({id:p.id,name:p.name,hand:p.hand,score:Number.isFinite(p.score)?p.score:0})),started:room.started,turn:room.turn,phase:room.phase,deckCount:room.deck.length,log:room.log.slice(0,40)}}
function send(ws,obj){if(ws.readyState===1)ws.send(JSON.stringify(obj))}
function broadcast(room){const s=JSON.stringify({type:'state',state:roomState(room)});room.players.forEach(p=>send(p.ws,JSON.parse(s)))}
function findPlayer(room,id){return room.players.find(p=>p.id===id)}
function refill(room,p){while(p.hand.length<4 && room.deck.length)p.hand.push(room.deck.pop())}
function advance(room){room.turn=(room.turn+1)%room.players.length;room.phase='cook'}
function resetGame(room){room.deck=shuffle([...DECK,...DECK]);room.players.forEach(p=>{p.hand=room.deck.splice(0,4);p.score=0});room.started=true;room.turn=0;room.phase='cook';room.log=[`ゲームスタート！ ${room.players[0].name}さんのターンです。`]}
function action(room,pid,a){if(!room.started)return;const p=findPlayer(room,pid);if(!p||room.players[room.turn].id!==pid)return;
 if(a.type==='cook'){
  if(room.phase!=='cook')return;const r=REC_MAP[a.recipe];if(!r||!canMake(p.hand,r.need))return;const h=removeNeed(p.hand,r.need);p.hand=h;p.score=Number(p.score)||0;p.score+=r.pts;refill(room,p);room.log.unshift(`${p.name}さんが「${r.name}」を完成！ +${r.pts}点`);advance(room);
 } else if(a.type==='discard'){
  if(room.phase!=='cook')return;const has=REC.some(r=>canMake(p.hand,r.need));if(has)return;const i=Number.isInteger(a.index)?a.index:-1;if(i<0||i>=p.hand.length)return;const card=p.hand.splice(i,1)[0];p.score=Number(p.score)||0;p.score-=point(card);room.log.unshift(`${p.name}さんが「${ING[card][1]}」を捨てました。 -${point(card)}点`);room.phase='draw';
 } else if(a.type==='draw'){
  if(room.phase!=='draw'||!room.deck.length)return;p.hand.push(room.deck.pop());room.log.unshift(`${p.name}さんがカードを1枚引きました。`);advance(room);
 }
 broadcast(room);
}
wss.on('connection',ws=>{
 ws.on('message',raw=>{let m;try{m=JSON.parse(raw)}catch{return}
  if(m.type==='create'){if(rooms.has(m.room))return send(ws,{type:'error',message:'そのルームIDは使用中です。'});if(!m.room||!m.name)return;const room={id:m.room,players:[],started:false,turn:0,phase:'cook',deck:[],log:[]};rooms.set(m.room,room);const p={id:m.id,name:String(m.name).slice(0,12),hand:[],score:0,ws};room.players.push(p);send(ws,{type:'joined',room:m.room,host:true,state:roomState(room)});broadcast(room)}
  else if(m.type==='join'){const room=rooms.get(m.room);if(!room)return send(ws,{type:'error',message:'ルームが見つかりません。'});if(room.started)return send(ws,{type:'error',message:'ゲーム開始後は参加できません。'});if(room.players.length>=8)return send(ws,{type:'error',message:'このルームは満員です。'});const p={id:m.id,name:String(m.name).slice(0,12),hand:[],score:0,ws};room.players.push(p);send(ws,{type:'joined',room:m.room,host:false,state:roomState(room)});broadcast(room)}
  else if(m.type==='start'){for(const room of rooms.values()){const p=findPlayer(room,m.id);if(p&&room.players[0].id===m.id){resetGame(room);broadcast(room);break}}}
  else if(m.type==='action'){for(const room of rooms.values()){if(findPlayer(room,m.id)){action(room,m.id,m.action);break}}}
 });
 ws.on('close',()=>{for(const [id,room] of rooms){const i=room.players.findIndex(p=>p.ws===ws);if(i>=0){room.players.splice(i,1);if(!room.players.length)rooms.delete(id);else{room.turn=Math.min(room.turn,room.players.length-1);broadcast(room)}break}}});
});
const PORT=process.env.PORT||10000;server.listen(PORT,()=>console.log(`Food loss game server listening on ${PORT}`));
